package com.dbmsproj.rentabike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentabikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
