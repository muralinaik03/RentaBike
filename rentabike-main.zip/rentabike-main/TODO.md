# TODO

### 1. Cancellation

    Implement cancellation of bookings

### 2. BikesModels Table

    Create a table called bikesModels which stores the details of bike model like name, mileage, etc.
    This results in alteration in various tables like bikes etc.
